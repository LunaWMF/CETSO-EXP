function [fitness] = EXP(I,Thresh)

    fitness = -EXP2(I,Thresh);
end