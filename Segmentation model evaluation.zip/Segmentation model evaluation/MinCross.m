

function [fitness] = MinCross(I,Thresh)

    fitness = MinCross2(I,Thresh);
end