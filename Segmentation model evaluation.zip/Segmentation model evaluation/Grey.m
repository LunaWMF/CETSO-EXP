function [fitness] = Grey(I,Thresh)

    fitness = -Grey2(I,Thresh);
end