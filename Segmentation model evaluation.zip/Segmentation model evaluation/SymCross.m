function [fitness] = SymCross(I,Thresh)

    fitness = SymCross2(I,Thresh);
end